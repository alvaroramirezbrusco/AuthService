﻿namespace Application.Models.RoleModels
{
    public class RoleResponseDTO
    {
        public int RoleId { get; set; }
        public string Name { get; set; }
    }
}
